package Api.pro.Configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;


@Configuration
public class WeatherServiceConfig {
    @Value("${world-weather-online.base-url}")
    private String baseUrl;

}

