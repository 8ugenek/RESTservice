package Api.pro.Configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;


@Configuration
public class CustomRestTemplate {

    // Inject the BaseUrlInterceptor bean into this class
    @Autowired
    private BaseUrlInterceptor baseUrlInterceptor;

    //creates and configures a bean for the RestTemplate
    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder restTemplateBuilder) {
        // Adds the BaseUrlInterceptor to the RestTemplate's additional interceptors
        return restTemplateBuilder
                .additionalInterceptors(baseUrlInterceptor)
                .build();
    }
}