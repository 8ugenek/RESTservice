package Api.pro.Configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyCfg {
    
    // Load the value of the UUID generator base URL from configuration
    @Value("${uuid-generator-api.base-url}")
    private String uuidGeneratorBaseUrl;


    // Creates and configures a bean for the BaseUrlInterceptor
    @Bean
    public BaseUrlInterceptor baseUrlInterceptor() {
         // Instantiate the BaseUrlInterceptor with the UUID generator base URL
        return new BaseUrlInterceptor(uuidGeneratorBaseUrl);
    }
}
