package Api.pro.Configuration;

import java.io.IOException;

import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.support.HttpRequestWrapper;

import java.net.URI;

public class BaseUrlInterceptor implements ClientHttpRequestInterceptor {
    private final String baseUrl;

     // Constructor to initialize the base URL
    public BaseUrlInterceptor(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
            throws IOException {
        // Modify the request URI using the baseUrl
        HttpRequest modifiedRequest = new HttpRequestWrapper(request) {
            @Override
            public URI getURI() {
                return URI.create(baseUrl + request.getURI().toString());
            }
        };
        // Execute the modified request and return the response
        return execution.execute(modifiedRequest, body);
    }
}


