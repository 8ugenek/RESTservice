package Api.pro.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Api.pro.Model.TripModel;

@Repository
public interface CustomTripRepos extends JpaRepository<TripModel, String> {

    //Query methods used within the repository by the corresponding service class 
    List<TripModel> findBySharedBy_Id(String userId);

    List<TripModel> findByStartDateGreaterThanEqualAndSharedBy_Id(LocalDate startDate, String userId);

    List<TripModel> findByStartDateGreaterThanEqual(LocalDate startDate);

    List<TripModel> findByLocation(String location); 

    List<TripModel> findByDurationInDaysGreaterThanEqual(Integer duration);

    List<TripModel> findByLocationAndStartDateGreaterThanEqual(String location, LocalDate startDate);

    List<TripModel> findByLocationAndDurationInDaysGreaterThanEqual(String location, Integer duration);

    List<TripModel> findByLocationAndStartDateGreaterThanEqualAndDurationInDaysGreaterThanEqual(
            String location, LocalDate startDate, Integer duration);

    Optional<TripModel> findById(String id);
}

