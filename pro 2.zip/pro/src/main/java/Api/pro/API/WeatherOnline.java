package Api.pro.API;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WeatherOnline {
    @Getter
    @Setter
    public static class Data {
        private List<WeatherResp> weather;
    }

    private Data data;
}