package Api.pro.API;


import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class WeatherResp {
    private LocalDate date;
    private Integer maxtempC;
    private Integer mintempC;
    private Integer avgtempC;
    private Double sunHour;
    private Integer uvIndex;
}

