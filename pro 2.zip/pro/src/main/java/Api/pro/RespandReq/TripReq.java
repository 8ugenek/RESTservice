package Api.pro.RespandReq;


import lombok.*;

import java.sql.Date;

@Getter
@Setter
public class TripReq {
    private String location;
    private Date startDate;
    private Integer durationInDays;
}
