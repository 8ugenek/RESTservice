package Api.pro.RespandReq;

import lombok.*;

@Getter
@Setter
public class UserReq {
    private String username;
    private String password;
    private Boolean isAdmin;
}
