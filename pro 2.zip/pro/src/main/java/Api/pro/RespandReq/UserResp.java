package Api.pro.RespandReq;

import lombok.*;

@Getter
@Setter
public class UserResp {
    private String id;
    private String username;
    private Boolean isAdmin;
}
