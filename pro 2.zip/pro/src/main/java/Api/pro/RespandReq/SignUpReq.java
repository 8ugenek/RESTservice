package Api.pro.RespandReq;

import lombok.*;

@Getter 
@Setter
public class SignUpReq {
    private String username;
    private String password;
}
