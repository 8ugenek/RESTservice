package Api.pro.RespandReq;

import lombok.*;


@Getter
@Setter
public class SignUpResp {
    public SignUpResp(String string) {
    }

    private String message;
}
