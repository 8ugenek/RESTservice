package Api.pro.RespandReq;


import lombok.*;

import java.time.LocalDate;
import java.util.List;

import Api.pro.API.WeatherResp;


@Getter
@Setter
public class TripResp {
    @Getter
    @Setter
    static class UserResp {
        private String username;
    }
    private String id;
    private String location;
    private LocalDate startDate;
    private Integer durationInDays;
    private List<WeatherResp> weather;
    private UserResp sharedBy;
    private List<UserResp> interestedUsers;
}
