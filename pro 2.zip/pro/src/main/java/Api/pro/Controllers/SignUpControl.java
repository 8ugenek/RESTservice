package Api.pro.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Api.pro.RespandReq.SignUpReq;
import Api.pro.RespandReq.SignUpResp;
import Api.pro.Service.SignUpService;

@RestController
@RequestMapping("/signup")
public class SignUpControl {
    

    private final SignUpService signUpService;

     // Constructor used to inject the SignUpService dependency
    @Autowired
    public SignUpControl(SignUpService signUpService) {
        this.signUpService = signUpService;
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SignUpResp> signUp(@RequestBody SignUpReq signUpReq) {
        SignUpResp signUpResp = signUpService.signUp(signUpReq);
        return ResponseEntity.ok(signUpResp);
    }
}
