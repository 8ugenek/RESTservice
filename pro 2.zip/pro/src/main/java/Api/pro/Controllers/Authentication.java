package Api.pro.Controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Api.pro.RespandReq.SignUpReq;
import Api.pro.RespandReq.SignUpResp;
import Api.pro.RespandReq.UserReq;
import Api.pro.RespandReq.UserResp;
import Api.pro.Service.SignUpService;
import Api.pro.Service.UserService;


@RestController
@RequestMapping("/auth")
public class Authentication {
    
    // These are the dependencies needed by the controller
    private final UserService userService;
    private final SignUpService signUpService;

    @Autowired
    public Authentication(UserService userService, SignUpService signUpService) {
        this.userService = userService;
        this.signUpService = signUpService;
    }

     // This method handles POST requests to /auth/signup endpoint
    @PostMapping("/signup")
    public ResponseEntity<SignUpResp> signup(@RequestBody SignUpReq signUpReq) {
        SignUpResp signUpResp = signUpService.signUp(signUpReq);
        // Return a response with the registration status
        return ResponseEntity.ok(signUpResp);
    }
    // This method handles POST requests for user login
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<?> login(@RequestBody UserReq userReq) {
        Optional<UserResp> userResp = userService.findUser(userReq.getUsername(), userReq.getPassword());

        // Checking if authentication was successful
        if (userResp.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        // Return the user information if authentication succeeded
        return ResponseEntity.ok(userResp.get());
    }

}






