package Api.pro.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import Api.pro.RespandReq.TripReq;
import Api.pro.RespandReq.TripResp;
import Api.pro.Service.TripService;


@RestController
@RequestMapping("/trips")
public class TripControl {

    private final TripService tripService;

    @Autowired
    public TripControl(TripService tripService) {
        this.tripService = tripService;
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<?> addTrip(@RequestHeader("Authorization") String currentUserId,
                                     @RequestBody TripReq tripReq) {
        try {
            TripResp createdTrip = tripService.addTrip(tripReq, currentUserId);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdTrip);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }
    // This method handles GET requests for retrieving trips
    @GetMapping
    public ResponseEntity<List<TripResp>> getTrips(@RequestParam(value = "available", required = false) Boolean available,
                                                            @RequestParam(value = "username", required = false) String username) {
        List<TripResp> trips = tripService.getTrips(available, username);
        return ResponseEntity.ok(trips);
    }
    // This method handles GET requests for retrieving a specific trip by ID
    @GetMapping("/{id}")
    public ResponseEntity<?> getTrip(@PathVariable("id") String tripId) {
        try {
              // Call the TripService to add a new trip and return the created trip
            TripResp trip = tripService.getTrip(tripId);
            return ResponseEntity.ok(trip);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    @PostMapping("/{id}/interestedUsers")
    public ResponseEntity<?> addInterest(@RequestHeader("Authorization") String currentUserId,
                                         @PathVariable("id") String tripId) {
        try {
            TripResp trip = tripService.addInterest(tripId, currentUserId);
            return ResponseEntity.status(HttpStatus.CREATED).body(trip);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }
}
















