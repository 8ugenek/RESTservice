package Api.pro.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import Api.pro.API.WeatherOnline;
import Api.pro.Service.WeatherService;



@RestController
public class WeatherControl {

    private final WeatherService weatherService;
    private final String apiKey;

    @Autowired
    public WeatherControl(WeatherService weatherService, @Value("${world-weather-online.apiKey}") String apiKey) {
        //initialise
        this.weatherService = weatherService;
        this.apiKey = apiKey;
      

    }
        // Define a GET endpoint to retrieve weather information
    @GetMapping("/weather")
    public WeatherOnline getWeather(
            @RequestParam String city,
            @RequestParam long days
    ) {
        // Call the WeatherService to get weather data using the API key
        return weatherService.getWeather(apiKey, days);
    }
}
    














