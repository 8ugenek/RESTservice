package Api.pro.Service;

import java.util.List;


public interface UUIDGen {

    List<String> generateUUIDs(int count);
    

  
}
