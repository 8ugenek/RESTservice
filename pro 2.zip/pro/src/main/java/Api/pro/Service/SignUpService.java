package Api.pro.Service;

import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Api.pro.Model.UserModel;
import Api.pro.Repository.CustomUserRepos;
import Api.pro.RespandReq.SignUpReq;
import Api.pro.RespandReq.SignUpResp;
import jakarta.annotation.PostConstruct;

@Service
public class SignUpService {

    private final CustomUserRepos customUserRepos;
   
    @Autowired
    public SignUpService(CustomUserRepos customUserRepos) {
        this.customUserRepos = customUserRepos;
    }

    @PostConstruct
    public void createInitialAdminUser() {
         // Check if admin user already exists
        Optional<UserModel> adminUser = customUserRepos.findByUsername("admin");
        // Generate a UUID for admin id
        // If admin user doesn't exist, create and save it
        if (!adminUser.isPresent()) {
            UserModel admin = new UserModel();
            admin.setId(UUID.randomUUID().toString()); 
            admin.setUsername("admin");
            admin.setPassword("admin1"); 
            admin.setIsAdmin(true);
            customUserRepos.save(admin);
        }
    }

    public SignUpResp signUp(SignUpReq signUpReq) {
        UserModel newUser = new UserModel();
        newUser.setUsername(signUpReq.getUsername());
        newUser.setPassword(signUpReq.getPassword());
        newUser.setIsAdmin(false); 

         // Save the new user
        customUserRepos.save(newUser);

        return new SignUpResp("User registered successfully");
    }
}