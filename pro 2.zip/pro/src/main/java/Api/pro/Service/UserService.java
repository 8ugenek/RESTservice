package Api.pro.Service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import Api.pro.Model.UserModel;
import Api.pro.Repository.CustomUserRepos;
import Api.pro.RespandReq.UserReq;
import Api.pro.RespandReq.UserResp;

import java.util.Optional;

@Service
public class UserService {

    private final ModelMapper modelMapper;

    private final UUIDGen uuidGen;
    private final CustomUserRepos customUserRepos;

    @Autowired
    public UserService(UUIDGen uuidGen, CustomUserRepos customUserRepos) {
        this.uuidGen = uuidGen;
        this.customUserRepos = customUserRepos;
        this.modelMapper = new ModelMapper();
    } 
    //add user
    @Transactional
    public UserResp addUser(UserReq userReq) {
        // Check if username already exists
        if (customUserRepos.findByUsername(userReq.getUsername()).isPresent()) {
            throw new IllegalArgumentException("Username already exists");
        }

        String userUUID = uuidGen.generateUUIDs(1).get(0);
        UserModel userModel = modelMapper.map(userReq, UserModel.class);
        userModel.setId(userUUID);
        customUserRepos.save(userModel);
        return modelMapper.map(userModel, UserResp.class);
    }
    //find user
    public Optional<UserResp> findUser(String username, String password) {
        Optional<UserModel> userModel = customUserRepos.findByUsernameAndPassword(username, password);
        return userModel.map(entity -> modelMapper.map(entity, UserResp.class));
    }
    //delete user 
    @Transactional
    public void deleteUser(String id) {
        if (!customUserRepos.existsById(id)) {
            throw new IllegalArgumentException("User not exists");
        }

        customUserRepos.deleteById(id);
    }

    // Check if a user is not an admin
    public boolean isNotAdmin(String id) {
        // Check if user exists and is not an admin
        Optional<UserModel> userModel = customUserRepos.findById(id);
        return userModel.isEmpty() || !userModel.get().getIsAdmin();
    }
}

    










