package Api.pro.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Api.pro.API.WeatherOnline;
import Api.pro.API.WeatherResp;
import Api.pro.Model.TripModel;
import Api.pro.Model.UserModel;
import Api.pro.Repository.CustomTripRepos;
import Api.pro.Repository.CustomUserRepos;
import Api.pro.RespandReq.TripReq;
import Api.pro.RespandReq.TripResp;
import jakarta.transaction.Transactional;


@Service
public class TripService {
    private final ModelMapper modelMapper;
    private final UUIDGen uuidGen;
    private final WeatherService weatherService;
    private final CustomTripRepos customTripRepos;
    private final CustomUserRepos customUserRepos;

    @Autowired
    public TripService(UUIDGen uuidGen,
                       WeatherService weatherService,
                       CustomTripRepos customTripRepos,
                       CustomUserRepos customUserRepos) {
        this.uuidGen = uuidGen;
        this.weatherService = weatherService;
        this.customTripRepos = customTripRepos;
        this.customUserRepos = customUserRepos;
        this.modelMapper = new ModelMapper();
    }

    @Transactional
    public TripResp addTrip(TripReq tripReq, String userId) {
        UserModel user = customUserRepos.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not exists"));

        String userUUID = uuidGen.generateUUIDs(1).get(0);
        TripModel tripModel = modelMapper.map(tripReq, TripModel.class);
        tripModel.setId(userUUID);
        tripModel.setSharedBy(user);
        tripModel.setInterestedUsers(Set.of());
        customTripRepos.save(tripModel);

        return mapTripModelToTripResp(tripModel);
    }
    // Get a list of trips based on availability and username  
    public List<TripResp> getTrips(Boolean available, String username) {
        UserModel user = customUserRepos.findByUsername(username)
                 .orElseThrow(() -> new IllegalArgumentException("User not exists"));

        // Determine trips based on availability and user presence
        final List<TripModel> trips;
        if (Boolean.TRUE.equals(available)) {
            trips = user != null ? customTripRepos.findByStartDateGreaterThanEqualAndSharedBy_Id(LocalDate.now(), user.getId())
                                  : customTripRepos.findByStartDateGreaterThanEqual(LocalDate.now());
        } else {
            trips = user != null ? customTripRepos.findBySharedBy_Id(user.getId())
                                  : customTripRepos.findAll();
        }

        return mapTripModelListToTripRespList(trips);
    }

    public TripResp getTrip(String id) {
        TripModel trip = customTripRepos.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Trip not found"));

        return mapTripModelToTripResp(trip);
    }

    // Add a user's interest to a trip
    @Transactional
    public TripResp addInterest(String tripId, String userId) {
        TripModel trip = customTripRepos.findById(tripId)
                .orElseThrow(() -> new IllegalArgumentException("Trip not found"));
        UserModel user = customUserRepos.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        // Update and save the trip with user's interest
        trip.getInterestedUsers().add(user);
        customTripRepos.save(trip);

        return mapTripModelToTripResp(trip);
    }

    private TripResp mapTripModelToTripResp(TripModel tripModel) {
        TripResp tripResp = modelMapper.map(tripModel, TripResp.class);
        tripResp.setWeather(getWeather(tripResp));
        return tripResp;
    }

    private List<TripResp> mapTripModelListToTripRespList(List<TripModel> tripModels) {
        return tripModels.stream()
                .map(this::mapTripModelToTripResp)
                .collect(Collectors.toList());
    }

    private List<WeatherResp> getWeather(TripResp trip) {
        LocalDate today = LocalDate.now();
        LocalDate startDate = trip.getStartDate();
        LocalDate endDate = startDate.plusDays(trip.getDurationInDays());

         // Check if weather details are available based on date ranges
        if (endDate.isBefore(today) || startDate.isAfter(today.plusDays(14))) {
            return List.of();
        }

           // Calculate the number of days between today and the trip's end date
        long days = ChronoUnit.DAYS.between(today, endDate);
        try {
            var weatherOnline = weatherService.getWeather(trip.getLocation(), days);
            return Optional.ofNullable(weatherOnline)
                    .map(WeatherOnline::getData)
                    .map(WeatherOnline.Data::getWeather)
                    .orElse(List.of())
                    .stream()
                    .filter(weatherResp -> !weatherResp.getDate().isBefore(startDate))
                    .collect(Collectors.toList());
        } catch (Exception e) {
            return List.of();
        }
    }
}





































/* 
public class TripService {
    private final ModelMapper modelMapper;
    private final UUIDGen uuidGen;
    private final WeatherService weatherService;
    private final CustomTripRepos customTripRepos;
    private final CustomUserRepos customUserRepos;



    @Autowired
    public TripService(UUIDGen uuidGen,
                       WeatherService weatherService,
                       CustomTripRepos customTripRepos, 
                       CustomUserRepos customUserRepos) {
        this.uuidGen = uuidGen;
        this.weatherService = weatherService;
        this.customTripRepos = customTripRepos;
        this.modelMapper = new ModelMapper();
        this.customUserRepos = customUserRepos;
    }

    @Transactional
    public TripResp addTrip(TripReq tripReq, String userId) {
        UserModel user = customUserRepos.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not exists"));

        String userUUID = uuidGen.generateUUIDs(1).get(0);
        TripModel tripModel = modelMapper.map(tripReq, TripModel.class);
        tripModel.setId(userUUID);
        tripModel.setSharedBy(user);
        tripModel.setInterestedUsers(Set.of());
        customTripRepos.save(tripModel);

        TripResp tripResp = modelMapper.map(tripModel, TripResp.class);
        var weather = getWeather(tripResp);
        tripResp.setWeather(weather);
        return tripResp;
    }

    public List<TripResp> getTrips(Boolean available, String username) {
        UserModel user = customUserRepos.findByUsername(username)
                 .orElseThrow(() -> new IllegalArgumentException("User not exists"));

        final List<TripModel> trips;
        if (Boolean.TRUE.equals(available) && user != null) {
            trips = customTripRepos.listAvailableAndSharedBy(user.getId());
        } else if (Boolean.TRUE.equals(available)) {
            trips = customTripRepos.listAvailable();
        } else if (user != null) {
            trips = customTripRepos.listAvailableAndSharedBy(user.getId());
        } else {
            trips = customTripRepos.findAll();
        }

        List<TripResp> tripResp = trips.stream()
                .map(trip -> {
                    TripResp tripResponse = modelMapper.map(trip, TripResp.class);
                    var weather = getWeather(tripResponse);
                    tripResponse.setWeather(weather);
                    return tripResponse;
                })
                .collect(Collectors.toList());

        return tripResp;
    }

    public TripResp getTrip(String id) {
        TripModel trip = customTripRepos.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Trip not found"));

        TripResp tripResp = modelMapper.map(trip, TripResp.class);
        var weather = getWeather(tripResp);
        tripResp.setWeather(weather);
        return tripResp;
    }

    @Transactional
    public TripResp addInterest(String tripId, String userId) {
        TripModel trip = customTripRepos.findById(tripId)
                .orElseThrow(() -> new IllegalArgumentException("Trip not found"));
        UserModel user = customUserRepos.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        trip.getInterestedUsers().add(user);
        customTripRepos.save(trip);

        TripResp tripResp = modelMapper.map(trip, TripResp.class);
        var weather = getWeather(tripResp);
        tripResp.setWeather(weather);
        return tripResp;
    }

    private List<WeatherResp> getWeather(TripResp trip) {
        LocalDate today = LocalDate.now();
        LocalDate startDate = trip.getStartDate().toLocalDate();
        LocalDate endDate = startDate.plusDays(trip.getDurationInDays());
        if (endDate.isBefore(today) || startDate.isAfter(today.plusDays(14))) {
            return List.of();
        }

        long days = ChronoUnit.DAYS.between(today, endDate);
        try {
            var weatherOnline = weatherService.getWeather(trip.getLocation(), days);
            return Optional.ofNullable(weatherOnline)
                    .map(WeatherOnline::getData)
                    .map(WeatherOnline.Data::getWeather)
                    .orElse(List.of())
                    .stream()
                    .filter(weatherResp -> !weatherResp.getDate().isBefore(startDate))
                    .collect(Collectors.toList());
        } catch (Exception e) {
            return List.of();
        }
    }
}
*/