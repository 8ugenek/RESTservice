package Api.pro.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class UUIDGenImpl implements UUIDGen {

    private final RestTemplate restTemplate;
    private final String baseUrl;

    public UUIDGenImpl(RestTemplate restTemplate, @Value("${uuid-generator-api.base-url}") String baseUrl) {
        this.restTemplate = restTemplate;
        this.baseUrl = baseUrl;
    }

    // Generate a list of UUIDs with the specified count
    @Override
    public List<String> generateUUIDs(int count) {
        String url = baseUrl + "/count/" + count;

         // Send a GET request to the UUID generation API
        ResponseEntity<List<String>> response = restTemplate.exchange(
            url,
            HttpMethod.GET,
            null,
            new ParameterizedTypeReference<List<String>>() {}
        );
        
        // Check the response status and return the generated UUIDs
        if (response.getStatusCode() == HttpStatus.OK) {
            return response.getBody();
        } else {
            throw new RuntimeException("Failed to fetch UUIDs");
        }
    }

    
}
