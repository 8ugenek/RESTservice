package Api.pro.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import Api.pro.API.WeatherOnline;

@Service
public class WeatherService {

    private final RestTemplate restTemplate;
    private final String apiKey;
    private final String baseUrl;

    @Autowired
    public WeatherService(
            RestTemplate restTemplate,
            @Value("${world-weather-online.api-key}") String apiKey,
            @Value("${world-weather-online.base-url}") String baseUrl) {
        this.restTemplate = restTemplate;
        this.apiKey = apiKey;
        this.baseUrl = baseUrl;
    }
    // Get weather information for a given city and number of days
    public WeatherOnline getWeather(String city, long days) {
        //url query parameters
        String url = UriComponentsBuilder.fromHttpUrl(baseUrl)
                .queryParam("key", apiKey)
                .queryParam("q", city)
                .queryParam("num_of_days", days)
                .queryParam("tp", 24)
                .queryParam("cc", "no")
                .queryParam("format", "json")
                .toUriString();

        // Send a GET request to the external weather API
        ResponseEntity<WeatherOnline> response = restTemplate.getForEntity(url, WeatherOnline.class);
        return response.getBody();
    }
}
    

