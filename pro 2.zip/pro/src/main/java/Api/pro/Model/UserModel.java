package Api.pro.Model;

import lombok.*;

import java.util.HashSet;
import java.util.Set;

import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;

@Getter
@Setter
@NoArgsConstructor

@Entity
@Table(name = "user_model")
@ToString
public class UserModel {
    //Stores each in a column of a table for user_model on external database 
    @Id
    private String id;
    
    @Column
    private String username;

    @Column
    private String password;

    @Column
    private Boolean isAdmin;

    @OneToMany(mappedBy = "sharedBy")
    private Set<TripModel> trips = new HashSet<>();

    @ManyToMany(mappedBy = "interestedUsers")
    private Set<TripModel> interestingTrips = new HashSet<>();


    public UserModel(String username, String password, Boolean isAdmin) {
        this.username = username;
        this.password = password;
        this.isAdmin = isAdmin;
    }
}