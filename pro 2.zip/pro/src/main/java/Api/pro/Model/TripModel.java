package Api.pro.Model;


import java.time.LocalDate;

import java.util.Set;

import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "trip_model")
public class TripModel {
    //Stores each in a column of a table for user_model on external database 
    @Id
    private String id;
  
    @Column
    private String location;
    
    @Column
    private LocalDate startDate;

    @Column
    private Integer durationInDays;
    
    // Establish a many-to-one relationship with the UserModel class
    @ManyToOne
    @JoinColumn(name = "shared_by_id")
    private UserModel sharedBy;

     // Establish a many-to-many relationship with the UserModel class through a join table
    @ManyToMany
    @JoinTable(
            name = "interesting_users_trip",
            joinColumns = @JoinColumn(name = "trip_id"),
            inverseJoinColumns = @JoinColumn(name = "user_id"))
    private Set<UserModel> interestedUsers;





}

    
