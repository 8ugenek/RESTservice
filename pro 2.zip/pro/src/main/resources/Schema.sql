CREATE TABLE IF NOT EXISTS users (
   id VARCHAR(255),
   isAdmin BOOLEAN DEFAULT FALSE,
   password VARCHAR(255) NOT NULL,
   username VARCHAR(255) NOT NULL UNIQUE,
   
   PRIMARY KEY (id)
);

INSERT INTO users (id, username, password, isAdmin)
VALUES ('admin-id', 'admin', 'admin1', TRUE)
ON CONFLICT (id) DO NOTHING;